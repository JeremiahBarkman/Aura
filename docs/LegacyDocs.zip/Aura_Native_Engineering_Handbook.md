# Aura Native Engineering Handbook

**Document Version:** 0.1 Draft  
**Project:** Aura Native Runtime  
**Status:** Engineering Handbook  
**Last Updated:** June 2026

---

# Purpose

The Aura Native Engineering Handbook serves as the primary reference for all native development within Aura.

Unlike the architecture documents, this handbook focuses on **how development is performed**, **why architectural decisions were made**, and **how future contributors should approach the native codebase**.

This document is intended to become the single entry point for native development.

---

# Handbook Structure

The handbook references the following foundational documents.

## Architecture

Defines the overall native system.

```
Aura_Native_Architecture.md
```

---

## Frame Transport

Defines the protocol between Aura Core and the native runtime.

```
Aura_Frame_Transport_Specification.md
```

---

## Development Standards

Defines coding conventions and implementation practices.

```
Aura_Native_Development_Guidelines.md
```

---

## Future Documentation

As Aura grows, this handbook will reference additional documents.

Examples include:

- Build Instructions
- Installer Guide
- Debugging Guide
- Performance Guide
- Coding Standards
- Architecture Decision Records (ADR)
- Release Checklist
- Testing Guide

---

# Native Runtime Philosophy

Aura intentionally separates intelligence from operating-system integration.

```
Aura Core

↓

Creates Meaning

↓

Native Runtime

↓

Delivers Pixels
```

This separation must never be compromised.

Business logic belongs in Aura Core.

Native code exists solely to provide platform capabilities.

---

# Native Runtime Responsibilities

The native runtime currently consists of:

```
AuraFrameBridge

AuraVirtualCamera

AuraDiagnostics

AuraInstaller
```

Future projects may be added, but every project must have a clearly defined responsibility.

---

# Engineering Principles

Every engineering decision should support the following goals.

## Simplicity

Simple code is preferred over clever code.

Readable code is preferred over compact code.

---

## Explicit Ownership

Every resource has one owner.

Ownership must be obvious.

Resources include:

- Memory
- Threads
- Handles
- Shared Memory
- Pipes
- GPU Resources

---

## Small Components

Classes should remain small.

Functions should remain focused.

Projects should remain independent.

---

## Stable Interfaces

Public interfaces should evolve slowly.

Internal implementation may evolve freely.

Consumers should rarely require changes.

---

## Design Before Code

New subsystems should begin with documentation.

Architecture should precede implementation.

Implementation should follow architecture.

---

# Engineering Workflow

Every significant feature follows the same lifecycle.

```
Idea

↓

Architecture

↓

Design Review

↓

Implementation

↓

Testing

↓

Documentation

↓

Release
```

Documentation is part of the feature.

A feature is incomplete until documentation has been updated.

---

# Development Workflow

The recommended workflow is:

## Step 1

Understand the architecture.

---

## Step 2

Identify the owning subsystem.

---

## Step 3

Determine ownership boundaries.

---

## Step 4

Implement the smallest possible change.

---

## Step 5

Verify behavior.

---

## Step 6

Document the result.

---

# Testing Philosophy

Aura emphasizes incremental verification.

Every subsystem should prove itself independently before integration.

Examples:

```
Shared Memory

↓

Verified
```

before

```
Virtual Camera
```

Examples:

```
Frame Transport

↓

Verified
```

before

```
Electron Integration
```

Subsystems are never debugged simultaneously.

---

# Debugging Philosophy

Debug only one unknown at a time.

Avoid introducing multiple changes before verification.

Preferred sequence:

```
Modify

↓

Build

↓

Verify

↓

Commit

↓

Next Change
```

---

# Logging Philosophy

Logging exists to answer:

"What happened?"

without attaching a debugger.

Logs should explain:

- Startup
- Shutdown
- Connections
- Failures
- Recoveries
- Performance

Avoid logging every frame.

---

# Performance Philosophy

Aura is a real-time application.

Latency is more important than perfect delivery.

Preferred:

```
Newest Frame Wins
```

Never allow old frames to create latency.

---

# Platform Philosophy

Platform-specific code should remain isolated.

Only dedicated platform layers should depend upon:

- Media Foundation
- DirectX
- Windows SDK
- COM

Common logic should remain platform independent whenever possible.

---

# Code Quality

Preferred characteristics:

- Small files
- Small classes
- Explicit ownership
- Predictable lifetime
- Clear interfaces
- Low coupling
- High cohesion

---

# Refactoring

Refactoring should improve:

- Readability
- Maintainability
- Testability

Refactoring should never change observable behavior.

Behavioral changes require separate verification.

---

# Architecture Decision Records (ADR)

Future architectural decisions should be recorded.

Examples:

```
ADR-001

Shared Memory selected over TCP.
```

```
ADR-002

Named Pipes selected for Electron communication.
```

```
ADR-003

Media Foundation selected for Windows Virtual Camera.
```

Documenting major decisions prevents future uncertainty.

---

# Native Roadmap

Near-term objectives.

## Phase 1

Shared Memory

Completed

---

## Phase 2

Frame Bridge

In Progress

---

## Phase 3

Virtual Camera

In Progress

---

## Phase 4

Electron Frame Export

Planned

---

## Phase 5

Native Diagnostics

Planned

---

## Phase 6

Installer

Planned

---

## Phase 7

Cross-platform Runtime

Future

---

# Long-Term Vision

The Aura Native Runtime should eventually support:

Windows

Linux

macOS

without changing Aura Core.

Platform-specific implementations should remain hidden behind common interfaces.

---

# Future Possibilities

Potential future native modules include:

- GPU Frame Conversion
- Hardware Encoding
- NDI Output
- RTMP Streaming
- Native Audio Bridge
- Screen Capture
- HDR Rendering
- Performance Telemetry
- Remote Diagnostics

---

# Engineering Motto

> Build small.

> Verify often.

> Design first.

> Document continuously.

---

# Project Vision

Aura is not simply a virtual camera.

Aura is a semantic visual operating environment.

The native runtime exists to connect Aura's semantic understanding to the operating system in the most efficient, reliable, and maintainable way possible.

Every engineering decision should reinforce that vision.

---

# Living Document

This handbook is expected to evolve throughout the lifetime of the Aura project.

When architecture changes, this handbook should be updated before significant implementation work continues.

The handbook represents the collective engineering knowledge of the Aura Native Runtime.

Maintaining it is considered part of the development process—not an afterthought.