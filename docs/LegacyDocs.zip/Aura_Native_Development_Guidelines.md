# Aura Native Development Guidelines

**Document Version:** 0.1 Draft  
**Project:** Aura Native Runtime  
**Status:** Development Standard  
**Last Updated:** June 2026

---

# Purpose

This document defines the engineering standards, coding conventions, and architectural principles governing all native C++ development within Aura.

Its purpose is to ensure that every native component remains:

- Maintainable
- Modular
- Testable
- Portable
- Predictable
- High performance

This document complements:

- Aura Native Architecture
- Aura Frame Transport Specification (AFTS)

Together these documents define:

- Architecture
- Transport
- Implementation standards

---

# Philosophy

Aura's native runtime is a production-quality software subsystem.

Every line of code should reflect the following principles:

- Simplicity
- Explicit ownership
- Minimal coupling
- Single responsibility
- Predictable behavior

Native code exists to provide capabilities unavailable to Electron—not to duplicate application logic.

---

# Guiding Principle

> **Electron owns intelligence.**

> **Native owns performance.**

Native code should never implement business logic, semantic reasoning, UI behavior, or application workflow.

---

# Project Organization

```
native/

    AuraNative.slnx

        AuraFrameBridge/

        AuraVirtualCamera/

        AuraDiagnostics/

        AuraInstaller/

        Common/

        Tests/

        docs/
```

Each project should have a single responsibility.

---

# Folder Structure

Each project should follow this layout:

```
Project/

    include/

    src/

    tests/

    docs/
```

For smaller projects, Visual Studio's Header Files / Source Files organization is acceptable.

---

# One Responsibility Per Class

Each class should have exactly one reason to change.

Good:

```
SharedMemory

NamedPipeServer

FrameConverter

FrameProvider

Logger
```

Bad:

```
BridgeManager

Utility

CommonFunctions

NativeManager
```

Avoid "God Objects."

---

# One Class Per File

Every public class receives:

```
ClassName.h

ClassName.cpp
```

Header:

Public interface only.

CPP:

Implementation only.

---

# Header Rules

Headers should:

- Minimize includes
- Prefer forward declarations
- Avoid implementation
- Avoid global variables

Headers define contracts.

CPP files contain behavior.

---

# Include Rules

Preferred include order:

```cpp
#include "ProjectHeader.h"

#include <system headers>

#include <standard library headers>
```

Project headers always appear first.

This catches missing dependencies.

---

# Naming Conventions

Classes:

```
SharedMemory

NamedPipeServer

FrameProvider
```

Methods:

```
Initialize()

WriteFrame()

ReadFrame()

Shutdown()
```

Variables:

```
frameNumber

sharedMemory

pipeHandle
```

Private members:

```
frameNumber_

sharedMemory_

pipeHandle_
```

Constants:

```
AuraFrameMagic

AuraPipeName

DefaultWidth
```

Macros should be avoided whenever possible.

---

# Resource Ownership

Every resource has exactly one owner.

Examples:

```
HANDLE

Memory Mapping

Pipe

Thread

Mutex

Texture
```

Ownership must be obvious from reading the class.

---

# RAII

Always prefer RAII.

Good:

```
Class owns HANDLE

Destructor closes HANDLE
```

Bad:

```
Initialize()

Shutdown()

Hope Shutdown() is called
```

Constructors acquire.

Destructors release.

---

# Memory Management

Prefer:

```
std::vector

std::array

std::string

std::unique_ptr

std::shared_ptr
```

Avoid:

```
new

delete

malloc

free
```

Unless absolutely required.

---

# Global State

Avoid mutable globals.

Allowed:

```
constexpr

const

compile-time constants
```

Avoid:

```
global buffers

global objects

global managers
```

---

# Threading

Every subsystem owns its own threads.

Threads never manipulate another subsystem's state directly.

Communication occurs only through:

- Shared Memory
- Named Pipes
- Immutable data structures

---

# Locking Philosophy

Prefer:

- Lock-free
- Immutable messages
- Single producer
- Multiple readers

Avoid:

- Large critical sections
- Nested locks
- Cross-subsystem locks

Blocking should be minimized.

---

# Error Handling

Every function should have a defined failure strategy.

Preferred:

```
Return false

Return std::optional

Return expected<T,E> (future)
```

Avoid:

Silent failure.

Undefined behavior.

---

# Logging

Every subsystem owns its own logging.

Future logging directory:

```
native/logs/
```

Logging should include:

- Startup
- Shutdown
- Errors
- Warnings
- Performance milestones

Avoid excessive logging in high-frequency loops.

---

# Assertions

Use assertions during development.

Example:

```
assert(width > 0);
```

Assertions document programmer assumptions.

Do not rely on assertions for runtime validation.

---

# Performance

Optimize for:

Low latency.

Predictable frame timing.

Stable frame pacing.

Avoid unnecessary:

- Memory copies
- Heap allocations
- Synchronization
- Thread creation

Measure before optimizing.

---

# Public APIs

Every public class should expose a minimal interface.

Example:

```
Initialize()

Shutdown()

Run()

WriteFrame()

ReadFrame()
```

Public APIs should remain stable.

---

# Internal APIs

Internal helper functions should remain private.

Avoid exposing implementation details.

---

# Transport Independence

Native code should not assume:

- Named Pipes
- Shared Memory
- TCP

Transport should be replaceable.

---

# Platform Independence

Common code should avoid:

Windows-specific APIs.

Only platform layers should depend upon:

- HANDLE
- COM
- Media Foundation
- DirectX

Everything else should remain portable.

---

# Testing

Every subsystem should have:

- Smoke tests
- Integration tests
- Performance tests

Future test project:

```
AuraNativeTests
```

---

# Diagnostics

Every subsystem should expose enough information to answer:

Is it running?

What is it doing?

What failed?

Without attaching a debugger whenever possible.

---

# Documentation

Every major class should include:

Purpose.

Responsibilities.

Dependencies.

Thread ownership.

Lifetime.

Public interface.

---

# Comments

Prefer explaining:

Why.

Avoid explaining:

What.

Example:

Good:

```cpp
// Latest frame wins to minimize latency.
```

Poor:

```cpp
// Increment i.
```

---

# Refactoring

Refactor when:

Responsibility changes.

Complexity increases.

Testing becomes difficult.

Avoid premature abstraction.

---

# Code Reviews

Before merging new native code, verify:

- Single responsibility
- RAII compliance
- Ownership clear
- Thread ownership documented
- Logging appropriate
- Error handling complete
- Documentation updated
- Architecture unchanged

---

# Native Development Workflow

Every feature should follow this sequence:

```
Design

↓

Architecture Review

↓

Implementation

↓

Unit Test

↓

Integration Test

↓

Performance Test

↓

Documentation Update
```

No feature is considered complete until documentation has been updated.

---

# Long-Term Vision

Aura's native runtime is expected to support:

- Windows
- Linux
- macOS

Future native components should require minimal platform-specific changes.

Architecture should favor portability from the beginning.

---

# Architectural Principle

> **Electron is the brain.**

> **Native is the nervous system.**

> **Windows is simply one endpoint.**

Aura's native runtime exists to transport, accelerate, and present the work produced by Aura Core—never to replace it.

Maintaining this separation ensures that Aura remains modular, scalable, portable, and maintainable for years to come.