# Aura Development Installation

## Required Tools

Aura currently requires:

- Node.js LTS
- Python 3.11 recommended
- FFmpeg / FFprobe
- npm
- SQLite through the `better-sqlite3` Node package

## Setup

From the project root:

```powershell
.\scripts\setup-dev.ps1