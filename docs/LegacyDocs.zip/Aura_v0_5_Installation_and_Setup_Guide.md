# Aura v0.5 Installation and Setup Guide

## Purpose

This document describes how to install, configure, launch, verify, and troubleshoot Aura v0.5.

Aura is a local-first Semantic Visual Presentation Engine that converts speech, semantic concepts, imported media, and AI-generated imagery into a searchable Semantic Visual Database.

---

# System Requirements

## Recommended

* Windows 11
* Intel i7 / Ryzen 7 or better
* 32 GB RAM
* NVIDIA RTX GPU
* SSD Storage

## Minimum

* Windows 10
* 16 GB RAM
* Modern GPU supporting WebGL

---

# Required Components

## Node.js

Required:

Node.js v22+

Verify:

```powershell
node -v
npm -v
```

---

## Python

Required for Whisper service.

Verify:

```powershell
python --version
```

---

## Ollama

Required.

Verify:

```powershell
ollama list
```

Recommended models:

* gemma3
* qwen3
* deepseek-v4

Default URL:

http://127.0.0.1:11434

---

## ComfyUI

Required.

Default URL:

http://127.0.0.1:8188

Verify in browser.

---

## SerpAPI

Required for image search and image import.

Environment variable:

SERPAPI_API_KEY=

Used for:

* Image Search
* Image Import
* Semantic Visual Database population

---

## PsySeg SDK

Required:

@personifyinc/psyseg-sdk

Environment variables:

PSYSEG_LICENSE=
PSYSEG_ACCESS_KEY=
PSYSEG_ACCESS_TOKEN=

---

# Project Layout

C:\Projects\aura

Important folders:

aura
│
├── data
│   ├── config
│   │   └── aura-config.json
│   │
│   ├── images
│   │   ├── generated
│   │   ├── imports
│   │   └── manual
│   │
│   ├── exports
│   └── imports
│
├── src
│   ├── db
│   ├── play
│   ├── image
│   ├── speech
│   ├── web
│   └── segmentation
│
├── public
├── docs
└── .env

---

# Environment Configuration

Create:

C:\Projects\aura.env

Example:

```env
PSYSEG_LICENSE=
PSYSEG_ACCESS_KEY=
PSYSEG_ACCESS_TOKEN=

OLLAMA_URL=http://127.0.0.1:11434
COMFYUI_URL=http://127.0.0.1:8188

SERPAPI_API_KEY=

PORT=5150
```

---

# Install Dependencies

```powershell
npm install
```

---

# Whisper Service

Launch:

```powershell
python src\speech\transcribe.py
```

Expected:

Listening on port 8765

Verify:

http://127.0.0.1:8765

Current implementation:

localWhisperService.js

Responsibilities:

* Transcription
* Audio duration metadata

---

# Launch Aura

```powershell
npm run electron
```

Expected:

* Electron window launches
* Aura UI loads
* Semantic Visual Library loads automatically
* Saved configuration restores automatically

---

# Aura Configuration System

Configuration file:

data/config/aura-config.json

Example:

```json
{
  "version": 1,
  "cameraDeviceId": "",
  "microphoneDeviceId": "",
  "displayMode": "single",
  "transitionType": "fade",
  "transitionDurationMs": 600,
  "minimumDisplayMs": 3000,
  "minimumMatchScore": 0.15,
  "activeLibraryGroupId": "",
  "libraryView": "all-complete",
  "outputBroadcastIntervalMs": 66
}
```

---

# Verify Services

Aura UI

http://localhost:5150

Aura Output

http://localhost:5150/aura-output/

Whisper

http://127.0.0.1:8765

Ollama

http://127.0.0.1:11434

ComfyUI

http://127.0.0.1:8188

---

# Current Stable Features

## Record Mode

* Audio recording
* Text entry
* Whisper transcription
* Ollama summarization
* Prompt generation
* Image generation
* Manual uploads
* Imported images

---

## Semantic Visual Library

* Complete records
* Draft records
* Group filtering
* Multi-image records
* Image reassignment
* Primary image assignment

---

## Groups

* Create
* Rename
* Delete
* Group-scoped Play Mode

---

## DB Manager

* Spreadsheet view
* Statistics
* Group filtering
* Bulk delete
* Bulk move
* Export group
* Export database
* Import package

---

## Scene Engine

* Single
* Dual
* Triple
* Aura

---

## Camera Output

* PsySeg replacement
* Active Scene application
* Active Scene auto-follow

---

## Slide Output

* Single
* Dual
* Triple
* Aura
* Stable transitions

---

## Configuration Persistence

* Camera
* Microphone
* Active Group
* Library View
* Display Settings

---

# Known Stability Notes

Aura is timing-sensitive.

Current stable value:

outputBroadcastIntervalMs = 66

Do not increase without profiling:

* UI responsiveness
* PsySeg performance
* Transition smoothness
* Broadcast load

---

# Current Development Priorities

Priority 1
Virtual Camera Integration

Priority 2
Executive Cleanup Pass

Priority 3
Installer Packaging

Priority 4
Transition Refinement

---

# Current Status

Aura is now a Semantic Visual Presentation Engine powered by a Semantic Visual Database.

Current focus:

Virtual Camera Integration
→ Packaging
→ Tester Distribution
