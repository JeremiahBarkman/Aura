# Aura v0.4 Installation and Setup Guide

## Purpose

This document describes how to install, configure, launch, and verify Aura v0.4.

Aura is a local-first semantic visualization engine that converts speech and semantic concepts into evolving visual scenes rendered as webcam backgrounds and presentation outputs.

---

# System Requirements

## Windows

Recommended:

* Windows 11
* Intel i7 / Ryzen 7 or better
* 32 GB RAM
* NVIDIA RTX GPU
* SSD Storage

Minimum:

* Windows 10
* 16 GB RAM
* Modern GPU supporting WebGL

---

# Required Components

Aura depends on:

## Node.js

Required:

```txt
Node.js v22+
```

Verify:

```powershell
node -v
npm -v
```

---

## Python

Required for Whisper service.

Verify:

```powershell
python --version
```

---

## Ollama

Install:

https://ollama.com

Verify:

```powershell
ollama list
```

Recommended models:

```txt
gemma3
qwen3
deepseek-v4
```

---

## ComfyUI

Required for image generation.

Default URL:

```txt
http://127.0.0.1:8188
```

Verify:

```txt
Open browser
http://127.0.0.1:8188
```

---

## PsySeg SDK

Aura uses:

```txt
@personifyinc/psyseg-sdk
```

Required credentials:

```env
PSYSEG_LICENSE=
PSYSEG_ACCESS_KEY=
PSYSEG_ACCESS_TOKEN=
```

---

# Project Layout

Project Root:

```txt
C:\Projects\aura
```

Important folders:

```txt
aura
│
├── data
│   ├── images
│   │   ├── generated
│   │   ├── imports
│   │   └── manual
│   │
│   ├── exports
│   └── imports
│
├── src
│   ├── db
│   ├── play
│   ├── image
│   ├── speech
│   ├── web
│   └── segmentation
│
├── public
├── docs
└── .env
```

---

# Environment Configuration

Create:

```txt
C:\Projects\aura\.env
```

Example:

```env
PSYSEG_LICENSE=YOUR_LICENSE
PSYSEG_ACCESS_KEY=YOUR_ACCESS_KEY
PSYSEG_ACCESS_TOKEN=YOUR_ACCESS_TOKEN

OLLAMA_URL=http://127.0.0.1:11434
COMFYUI_URL=http://127.0.0.1:8188

PORT=5150
```

---

# Install Dependencies

From project root:

```powershell
npm install
```

---

# Whisper Service

Start Whisper:

```powershell
python src\speech\transcribe.py
```

Expected:

```txt
Listening on port 8765
```

Verify:

```txt
http://127.0.0.1:8765
```

---

# Launch Aura

From project root:

```powershell
npm run electron
```

Expected:

```txt
Aura UI launches
Electron window opens
```

---

# Verify Services

## Aura UI

```txt
http://localhost:5150
```

---

## Aura Output

```txt
http://localhost:5150/aura-output/
```

---

## Whisper

```txt
http://127.0.0.1:8765
```

---

## Ollama

```txt
http://127.0.0.1:11434
```

---

## ComfyUI

```txt
http://127.0.0.1:8188
```

---

# Current Stable Features

## Record Mode

* Audio recording
* Text entry
* Whisper transcription
* Ollama summarization
* Prompt generation
* Image generation
* Manual image upload

---

## Semantic Library

* Complete records
* Draft records
* Group filtering
* Multi-image records
* Manual image assignment

---

## Groups

* Create
* Rename
* Delete
* Group-scoped matching

---

## DB Manager

Implemented:

* Spreadsheet view
* Statistics
* Group filtering
* Bulk delete
* Bulk move
* Export group
* Export database
* Import package

---

## Scene Engine

Implemented:

* Single Mode
* Dual Mode
* Triple Mode
* Aura Mode

---

## Scene Memory Engine

Implemented:

### SceneSlotManager

Supports:

* Primary slot
* Supporting slots
* Promotion logic
* Duplicate prevention
* Match refresh
* Supporting slot rotation

---

## Active Scene v3

Supports:

```txt
Primary
Supporting Left
Supporting Right
Transition Metadata
```

---

## Camera Output

Supports:

* PsySeg replacement
* Active Scene application
* Active Scene auto-follow

---

## Slide Output

Supports:

* Active Scene polling
* Scene rendering
* Single
* Dual
* Triple
* Aura layouts

---

# Current Known Issues

## Transition System

Current:

```txt
Works
```

Needs refinement:

```txt
Per-slot transitions
Slot diffing
Crossfades
Feathered blending
```

---

## Virtual Camera

Not yet integrated.

Planned:

```txt
SceneRenderer
→ Virtual Camera Driver
```

---

## Installer

Not yet packaged.

Current installation is developer-focused.

---

# Development Priorities

Priority 1

Transition Engine Refinement

* Slot diff engine
* Slot crossfades
* Feathering
* Visual polish

---

Priority 2

Code Cleanup

* Remove orphaned code
* Remove browser-era remnants
* Improve comments
* Executive review readiness

---

Priority 3

Virtual Camera Integration

* Teams
* Zoom
* Meet
* Discord
* OBS

---

Priority 4

Installer Packaging

* Electron packaging
* Dependency validation
* Beta tester distribution

---

# Current Architecture

Speech
↓
Play Match
↓
SceneSlotManager
↓
Active Scene v3
↓
SceneRenderer
↓
Camera Output
↓
Slide Output
↓
Future Virtual Camera

Aura is no longer a background replacement application.

Aura is now a semantic scene memory engine that maintains and visualizes conversational context in real time.
