# Aura v0.3 Status Summary & Updated Installation Notes

## Current System State

Aura is now operating as a fully local-first AI semantic media and virtual webcam platform.

### Operational Stack

```txt
Electron Desktop Runtime
→ Aura Local Web UI
→ PsySeg Segmentation Engine
→ Local Whisper Speech Service
→ Ollama Semantic Processing
→ ComfyUI Image Generation
→ SQLite Semantic Visual Database
→ OBS-Compatible Aura Output Window
```

## Current Capabilities

- Electron desktop runtime
- PsySeg licensed segmentation integration
- Local Whisper transcription
- Ollama semantic processing
- ComfyUI image generation
- Semantic visual database
- Manual image uploads
- Draft vs Complete workflow
- Library Groups
- Group-scoped Play Mode matching
- Image Search Import (SerpAPI)
- Imported image local storage
- Imported image enrichment via Ollama
- Multi-image records
- Multi-view library filtering
- Full record deletion
- Manual image attachment to existing records
- OBS-compatible output
- System health monitoring
- Environment-based credential management

---

# Semantic Visual Library

## Record Architecture

```txt
Record
├── Source Text
├── Summary
├── Image Prompt
├── Trigger Text
└── Images (1..N)
```

A record represents a semantic concept.

Multiple images may be attached to a single record.

## Library Views

```txt
All Complete Records
All Draft Records
All Records
Group Views
```

## Groups

```txt
Library Groups
├── Space
├── Synth Friends
├── Museum
└── User Defined Groups
```

---

# Group-Scoped Play Mode

```txt
Play Mode
→ Active Group Selection
→ Complete Record Filtering
→ Semantic Matching
→ Matching Record
→ Active Image Selection
→ Background Replacement
```

Only COMPLETE records participate in matching.

---

# Image Search Import Pipeline

```txt
User Search
→ SerpAPI
→ Image Download
→ Ollama Enrichment
→ Draft Record Creation
→ Library Assignment
```

Imported images stored in:

```txt
data/images/imports
```

### Enrichment Pipeline

```txt
Search Metadata
→ Ollama
→ Summary
→ Image Prompt
→ Trigger Text
→ Draft Record
```

Fallback mode:

```txt
If Ollama unavailable
→ Import still succeeds
→ Metadata-based content generated
```

---

# Whisper Speech Pipeline

```txt
Microphone
→ MediaRecorder
→ Local Whisper Service
→ Transcript
→ Semantic Processing
→ Aura Database
```

Whisper Endpoint:

```txt
http://127.0.0.1:8765/transcribe
```

---

# OBS Output

```txt
Camera
→ PsySeg
→ Background Replacement
→ Aura Output Window
→ OBS Browser Source
```

OBS URL:

```txt
http://localhost:5150/aura-output/
```

---

# Environment Variables

```env
PSYSEG_LICENSE=YOUR_LICENSE
PSYSEG_ACCESS_KEY=YOUR_ACCESS_KEY
PSYSEG_ACCESS_TOKEN=YOUR_ACCESS_TOKEN
```

`.env` must be excluded from source control.

---

# Launch

```powershell
cd C:\Projects\aura
npm run electron
```

---

# Ports

```txt
Aura UI          → http://localhost:5150
Aura Output      → http://localhost:5150/aura-output/
Whisper Service  → http://127.0.0.1:8765
ComfyUI          → http://127.0.0.1:8188
Ollama API       → http://127.0.0.1:11434
```

---

# Stable Features

- Semantic Play Mode
- Group-scoped Play Mode
- PsySeg segmentation
- OBS output
- Local Whisper transcription
- Ollama processing
- Ollama import enrichment
- ComfyUI generation
- Draft workflow
- Library Groups
- Multi-image records
- Image Search Import
- Local database persistence
- Record review workflow

---

# Known Issues

- Transition compositor still experimental
- No packaged installer yet
- No vector embedding search yet
- No true virtual webcam driver layer yet
- DB Manager not yet implemented
- Export / Import workflow not yet implemented
- Record-level image rotation/selection not yet implemented
- Performance optimization pass still needed

---

# Planned DB Manager

- Spreadsheet-style record view
- Bulk delete
- Bulk move
- Bulk copy
- Bulk mark complete
- Group management
- Group statistics
- Record statistics
- Export Group
- Import Group
- Export Database
- Import Database

---

# Recommended Next Priorities

1. DB Manager foundation
2. Export / Import system
3. Record-level image selection and rotation
4. Stabilize transition architecture
5. Virtual webcam device layer
6. Vector embedding semantic search
7. Packaging and distribution
8. GPU/performance instrumentation
9. Improve semantic ranking

---

# New Session Context

## Current Focus

- DB Manager foundation
- Export / Import architecture
- Record-level image selection
- Transition compositor architecture
- Virtual webcam layer
- Performance optimization
- Packaging/distribution

## Development Rules

- Build incrementally
- One subsystem at a time
- No full rewrites
- Preserve modular architecture
- Keep segmentation provider abstracted behind interfaces
- Prioritize real-time performance
- Avoid hardcoded credentials
- Prefer explicit resource ownership
