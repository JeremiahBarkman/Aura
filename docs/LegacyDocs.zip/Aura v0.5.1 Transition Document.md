# Aura v0.5.1 Transition Document

## Current Status

Aura is currently functioning as a local-first semantic visual memory platform with:

* Record Mode
* Play Mode
* Scene Memory Engine
* Multi-image scene composition
* PsySeg background replacement
* Aura Output
* Slide Output
* Group-aware semantic matching
* DB Manager
* Import / Export packages

The application is stable and suitable for executive demonstration.

---

# Recent Fixes Completed

## SceneSlotManager Stability

Removed duplicate scene insertion logic from:

```txt
/api/play/match
```

SceneSlotManager now remains in:

```txt
aura
```

mode internally.

Display mode projection occurs at the presentation layer rather than inside the scene engine.

---

## Slide Output Display Mode Fix

Slide Output now correctly respects:

```txt
1 Image
2 Images
3 Images
Aura
```

settings.

Previously Slide Output always displayed Aura mode because it rendered the raw SceneSlotManager scene.

Display projection logic was added to:

```txt
public/aura-slide-output/index.html
```

---

## Dual Image Slot Fix

Dual image mode now displays the most recent semantic matches rather than simply using slots 0 and 1.

Previously a match could appear in slot 3 and be hidden while operating in 2-image mode.

---

## Play Mode UI Cleanup

The Active Background Match section was simplified.

Removed oversized card presentation.

Current layout is compact and readable.

---

# Architecture Status

Current architecture:

Speech
→ Whisper

Whisper Text
→ Semantic Match

Semantic Match
→ Scene Memory Engine

Scene Memory
→ Display Projection

Display Projection
→

Aura Output
Slide Output
PsySeg Background Replacement

---

# Important Discovery

Aura Output frame rate issues are isolated to:

Canvas
→ createImageBitmap()
→ BroadcastChannel
→ Aura Output Window

The rendering engine itself remains smooth.

This path is considered temporary.

Do not spend additional effort optimizing the BroadcastChannel preview path.

---

# Next Development Priority

## Virtual Camera Architecture

Create:

```txt
src/virtual-camera/
```

Create:

```txt
VirtualCameraProvider.js
```

Interface only.

Required methods:

```txt
initialize()
start(width, height, fps)
submitFrame(frameSource)
stop()
dispose()
```

Aura core must not depend on a specific virtual camera implementation.

Follow the same abstraction pattern used by:

```txt
SegmentationProvider
└── PsySegSegmentationProvider
```

---

# Future Research Thread

A major conceptual discovery occurred during this session.

Aura may be evolving beyond a semantic visual library toward:

```txt
Semantic Visual Memory
```

Current Aura stores:

* Raw Text
* Summary
* Trigger Text
* Generated Images
* Imported Images
* Metadata

These are effectively components of a memory object.

Potential future direction:

```txt
Memory Object

Raw Speech
Summary
Trigger Text
Images
Metadata
Embedding
```

instead of treating records as independent assets.

---

# Research Areas To Explore

## Multimodal Retrieval

Retrieve:

* Images
* Video
* Documents
* Audio
* Metadata

through a unified semantic search.

---

## Speech-Image Grounding

Direct association between spoken concepts and visual concepts.

Potential future Play Mode enhancement.

---

## Memory-Augmented Vision-Language Systems

Persistent retrieval of contextual information rather than keyword matching.

Potential future evolution of Scene Memory Engine.

---

# Long-Term Vision

Current Aura:

Speech
→ Match
→ Image

Potential Aura:

Speech
→ Memory Retrieval
→ Context Retrieval
→ Visual Retrieval
→ Scene Composition
→ Presentation Output

Aura increasingly resembles:

```txt
A Semantic Visual Memory System
```

rather than:

```txt
AI Webcam Software
```

---

# Immediate Goal For Next Session

Do NOT begin embeddings.

Do NOT begin vector databases.

First complete:

```txt
Virtual Camera Architecture
```

Create provider abstraction.

Design interfaces.

Determine frame ownership.

Determine renderer integration path.

Keep implementation details separate from Aura core.
