# Aura v0.3 Development Handoff

## Project Identity

Aura is a local-first AI semantic media and virtual webcam platform.

Primary user experience:

```txt
User speaks
→ Local speech-to-text
→ Semantic matching
→ Matching record selected
→ Matching image selected
→ PsySeg background replacement
→ Virtual camera / OBS output
```

---

# Current Architecture

```txt
Electron
├── Aura Server
├── Whisper Service
├── Ollama
├── ComfyUI
└── UI Windows

Aura Server
├── SQLite
├── Record Mode
├── Play Mode
├── Library Management
├── Image Search Import
└── PsySeg Integration
```

---

# Completed Major Milestones

## Core Platform

- Electron runtime operational
- SQLite persistence operational
- Whisper transcription operational
- Ollama semantic processing operational
- ComfyUI generation operational
- PsySeg operational
- OBS output operational

## Record Workflow

- Draft / Complete workflow
- Record review UI
- Record editing
- Record completion controls
- Multi-image records

## Library System

- Library Groups
- Group assignment
- Group filtering
- All Complete view
- All Drafts view
- All Records view
- Record metadata display

## Play Mode

- Complete-record filtering
- Group-scoped matching
- Active image display
- Real-time matching

## Import System

- SerpAPI image search
- Local image download
- Import image storage
- Draft creation
- Ollama enrichment
- Metadata fallback

---

# Critical Architectural Rules

## Record Is The Semantic Unit

Aura should treat:

```txt
Record
= semantic concept
```

NOT:

```txt
Image
= semantic concept
```

Correct model:

```txt
Record
├── Image A
├── Image B
├── Image C
```

Play Mode should eventually:

```txt
Match Record
↓
Choose Image
```

NOT:

```txt
Match Individual Image
```

---

# Current Database Concepts

## source_items

Owns:

```txt
raw text
status
group
metadata
```

## summaries

Owns:

```txt
summary text
image prompt
```

## trigger_texts

Owns:

```txt
original trigger text
cleaned trigger text
```

## generated_images

Owns:

```txt
image path
active flag
favorite flag
workflow info
```

Multiple generated_images rows may belong to one record.

---

# Current Stable Features

```txt
✔ Semantic Play Mode
✔ Group-scoped Play Mode
✔ Draft workflow
✔ Complete workflow
✔ Library Groups
✔ Multi-image records
✔ Record deletion
✔ Manual image uploads
✔ Imported images
✔ Ollama enrichment
✔ SerpAPI imports
✔ OBS output
✔ Local-only architecture
```

---

# Known Technical Debt

## DB Manager Missing

Highest priority UI gap.

Needed:

```txt
Spreadsheet view
Bulk delete
Bulk move
Bulk copy
Bulk complete
Group management
Statistics
```

---

## Export / Import Missing

Needed:

```txt
Export Group
Import Group

Export Database
Import Database
```

Must include:

```txt
records
images
groups
metadata
```

Goal:

Portable Aura libraries.

---

## Record-Level Image Selection

Needed:

```txt
Record
├── Image A
├── Image B
├── Image C
```

Play Mode options:

```txt
Favorite First
Random
Rotate
Manual Preferred
```

---

## Embeddings

Current matching:

```txt
keyword matching
```

Future:

```txt
vector search
semantic similarity
ranking
```

---

# Recommended Next Sprint

## Sprint 1 — DB Manager Foundation

Build:

```txt
DB Manager Screen
```

Features:

```txt
Record Count
Group Count
Bulk Select
Bulk Delete
Bulk Move
Bulk Mark Complete
```

Do NOT build everything at once.

---

## Sprint 2 — Export / Import

Features:

```txt
Export Group
Import Group
Export Database
Import Database
```

Portable backups become mandatory as content grows.

---

## Sprint 3 — Image Selection Engine

Implement:

```txt
Match Record
↓
Choose Image
```

Support:

```txt
Favorite
Random
Rotate
```

---

# Important Files

## Import System

```txt
src/import/imageSearchImportService.js
src/import/imageEnrichmentService.js
```

## Semantic Processing

```txt
src/llm/ollamaService.js
```

## Speech

```txt
src/speech/localWhisperService.js
```

## Database

```txt
src/db/
```

## UI

```txt
src/web/
```

---

# Environment Requirements

```env
PSYSEG_LICENSE=...
PSYSEG_ACCESS_KEY=...
PSYSEG_ACCESS_TOKEN=...
```

Never hardcode credentials.

User specifically requested notification if additional hardcoded secrets are discovered.

---

# Development Rules

- Build incrementally
- One subsystem at a time
- No full rewrites
- Preserve modular architecture
- Keep segmentation abstracted
- Avoid hidden async behavior
- Avoid UI thread blocking
- Prefer small testable modules
- Preserve real-time performance

---

# First Task For Next Session

Begin DB Manager Foundation.

Goal:

```txt
Dedicated DB Management Screen
```

Initial deliverables:

```txt
Record Statistics
Group Statistics
Bulk Selection
Bulk Delete
Bulk Move
Bulk Mark Complete
```

This is now the highest leverage improvement for Aura.
