# Aura v0.4 – Scene Memory Architecture Transition Document

## Executive Summary

Aura has evolved beyond a virtual background application.

Aura is now a local-first semantic visualization engine that converts speech, text, and semantic concepts into evolving visual scenes which can be rendered into:

* Aura Slide Output
* Aura Camera Background
* Future Virtual Camera Output
* OBS
* Streaming Platforms

The defining architectural advancement of v0.4 is the introduction of the Scene Memory Engine.

Instead of replacing backgrounds one image at a time, Aura now maintains a semantic scene composed of primary and contextual imagery that evolves as conversation topics change.

---

# Core Vision

Aura is no longer:

Speech → Image → Background

Aura is now:

Speech
↓
Semantic Understanding
↓
Scene Memory
↓
Visual Context
↓
Camera / Virtual Camera Output

Aura behaves more like a visual working memory system than a traditional webcam filter.

---

# Current Operational Stack

Electron Desktop Runtime
→ Aura Local Web UI
→ PsySeg Segmentation Engine
→ Whisper Local STT
→ Ollama Semantic Processing
→ SQLite Semantic Visual Database
→ SceneSlotManager
→ Active Scene v3
→ SceneRenderer
→ Camera Output
→ OBS Output

Future:

→ Virtual Camera Driver

---

# Major New Architecture

## SceneSlotManager

New subsystem:

src/play/SceneSlotManager.js

Responsibilities:

* Own scene state
* Own slot assignments
* Prevent duplicate images
* Manage promotion logic
* Manage supporting image rotation
* Produce Active Scene v3

---

# Active Scene v3

Scene state is now:

{
version: 3,
sceneMode: 'aura',
slots: [],
transition: {},
updatedAt: timestamp
}

This is now the single source of truth for all visual outputs.

---

# Scene Modes

## Single

Slot 0
→ Primary

---

## Dual

Slot 0
→ Primary

Slot 1
→ Supporting

---

## Triple

Slot 0
→ Left

Slot 1
→ Primary

Slot 2
→ Right

---

## Aura

Slot 0
→ Primary

Slot 1
→ Supporting Left

Slot 2
→ Supporting Right

Aura Mode is now the primary presentation model.

---

# Scene Memory Behavior

Current logic:

First Match
→ Primary

Second Match
→ Supporting Left

Third Match
→ Supporting Right

Additional Matches
→ Replace Oldest Supporting

Duplicate Match
→ Refresh Existing Slot

High Confidence Match
→ Promote To Primary

Old Primary
→ Moved Into Supporting Rotation

This creates a living visual memory of the conversation.

---

# Active Scene Flow

Play Match
↓
SceneSlotManager.insertMatch()
↓
Active Scene v3
↓
SceneRenderer
↓
Outputs

---

# Outputs

## Slide Output

Polls Active Scene

Automatically updates

Supports:

* Single
* Dual
* Triple
* Aura

---

## Camera Output

Auto-follow support implemented.

Active Scene changes automatically update camera background.

No manual refresh required.

---

# Current Stable Features



## Record Mode

* Whisper transcription
* Ollama summarization
* Trigger extraction
* Image generation
* Draft workflow

## Library

* Complete records
* Draft records
* Group views
* Manual uploads
* Imported images

## Groups

* Group-scoped Play Mode
* Group management

## DB Manager

Implemented:

* Statistics
* Spreadsheet view
* Bulk delete
* Bulk move
* Group filtering
* Export
* Import

---

# Architectural Findings

## Legacy Browser Pipeline Exists

Older browser-era segmentation code remains:

PsySegSegmentationProvider.js

Current architecture:

SceneRenderer
→ LiveCompositor
→ PsySeg
→ Camera Output

Future development should target the Electron pipeline.

Brittle timing point:

Aura Output broadcast frame rate directly affects Control Panel responsiveness.

requestAnimationFrame caused dropdown/input lag when broadcasting the live canvas continuously.

Current stable setting:
setTimeout(frame, 66)
≈ 15fps

Do not increase output broadcast rate without profiling UI responsiveness, PsySeg load, and BroadcastChannel overhead.

---

# Current Development Priorities

## Priority 1

Transition System Refinement

Goals:

* Per-slot transitions
* Slot-level crossfades
* Feathered blending
* Transition timing controls
* Cinematic scene evolution
* Reduce full-scene redraws

---

## Priority 2

Codebase Cleanup

Goals:

* Remove orphaned browser-era code
* Consolidate rendering paths
* Remove dead routes
* Remove duplicate rendering logic
* Improve comments
* Improve presentation quality

Objective:

Prepare architecture for executive review.

---

## Priority 3

Virtual Camera Integration

Goals:

SceneRenderer
↓
Camera Output
↓
Virtual Camera Driver

Support:

* Teams
* Zoom
* Google Meet
* OBS
* Discord

---

## Priority 4

Tester Distribution

Goals:

* Electron packaging
* Environment validation
* Installer creation
* Dependency verification
* Portable test package
* Reproducible installation

Target:

Non-technical beta testers.

---

# Longer-Term Roadmap

Phase 1
✓ Semantic Scene Memory

Phase 2
→ Transition Engine

Phase 3
→ Virtual Camera Driver

Phase 4
→ Installer Distribution

Phase 5
→ Vector Embeddings

Phase 6
→ Semantic Scene Ranking

Phase 7
→ Multi-Agent Content Generation

---

# Development Rules

* Build incrementally
* One subsystem at a time
* Preserve modular architecture
* No full rewrites
* Keep segmentation abstracted behind provider interfaces
* Prioritize real-time performance
* Avoid hidden resource ownership
* Avoid hardcoded credentials
* Maintain reproducible installation process

---

# Current Status

Aura has successfully evolved from a semantic background replacement prototype into a semantic scene memory engine capable of maintaining and visualizing conversational context in real time.

The next milestone is visual refinement of scene transitions followed by virtual camera output and tester distribution.
