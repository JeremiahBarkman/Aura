# Aura v0.5 – Semantic Visual Database & Configuration Milestone

## Executive Summary

Aura has evolved beyond a virtual background application and beyond a simple Scene Memory Engine.

Aura is now a local-first Semantic Visual Presentation Engine powered by a Semantic Visual Database.

Aura converts speech, text, imported media, and AI-generated imagery into a searchable visual knowledge base capable of automatically driving:

* Aura Output
* Camera Background Replacement
* Slide Output
* OBS
* Future Virtual Camera Output

The defining milestone of v0.5 is the emergence of the Semantic Visual Database as the central architecture component.

---

# Core Vision

Aura is no longer:

Speech
→ Image
→ Background

Aura is now:

Speech
↓
Semantic Understanding
↓
Semantic Visual Database
↓
Scene Memory
↓
Visual Context
↓
Presentation Output

Aura behaves more like a visual working memory system than a webcam filter.

---

# Current Operational Stack

Electron Desktop Runtime
→ Aura Local Web UI
→ PsySeg Segmentation Engine
→ Whisper Local STT
→ Ollama Semantic Processing
→ SQLite Semantic Visual Database
→ SceneSlotManager
→ Active Scene v3
→ SceneRenderer
→ Aura Output
→ OBS Output

Future:

→ Virtual Camera Driver

---

# Semantic Visual Database Architecture

Multiple content pipelines now contribute visual assets.

```
                ComfyUI
                   │
                   ▼
```

Whisper → Ollama → Semantic Visual Database ← SerpAPI
▲
│
Manual Uploads
│
▼
Scene Memory Engine
▼
Scene Renderer
▼
Aura Output / OBS / Virtual Camera

The Semantic Visual Database is now the primary asset and system of record.

---

# Current Stable Features

## Record Mode

Implemented:

* Audio recording
* Whisper transcription
* Ollama summarization
* Trigger extraction
* Prompt generation
* Image generation
* Manual image upload
* Imported image workflow

---

## Semantic Visual Library

Implemented:

* Complete records
* Draft records
* Group views
* Group filtering
* Multi-image records
* Manual uploads
* Imported images
* Primary image assignment
* Move image between records
* Automatic draft conversion when last image removed

---

## Groups

Implemented:

* Create
* Rename
* Delete
* Group-scoped Play Mode
* Group filtering

---

## DB Manager

Implemented:

* Spreadsheet view
* Statistics
* Group filtering
* Bulk delete
* Bulk move
* Export group
* Export database
* Import package

---

## Scene Engine

Implemented:

* Single Mode
* Dual Mode
* Triple Mode
* Aura Mode

---

## Scene Memory Engine

Implemented:

### SceneSlotManager

Supports:

* Primary slot
* Supporting slots
* Promotion logic
* Duplicate prevention
* Supporting rotation

---

## Active Scene v3

Supports:

Primary
Supporting Left
Supporting Right
Transition Metadata

---

## Camera Output

Implemented:

* PsySeg replacement
* Active Scene application
* Active Scene auto-follow
* Stable transition system

---

## Slide Output

Implemented:

* Single
* Dual
* Triple
* Aura layouts
* Active Scene polling
* Stable transitions

---

# New v0.5 Features

## Aura Configuration System

Implemented:

data/config/aura-config.json

Persisted:

* Camera Device
* Microphone Device
* Active Play Mode Group
* Library View
* Display Mode
* Transition Type
* Transition Duration
* Minimum Display Time
* Minimum Match Score

---

## Activity Log System

Implemented:

Provides user-visible status updates for:

* Startup
* Camera
* Library
* Display Settings
* Imports
* Exports
* Image moves
* System operations

---

## Library Startup Improvements

Implemented:

* Semantic Visual Library auto-load
* Camera restore
* Microphone restore
* Display settings restore
* Group restore
* Library view restore

---

## Audio Pipeline Fixes

Implemented:

* localWhisperService now owns transcription
* localWhisperService now owns audio duration metadata
* legacy speech service retired

---

# Important Architectural Findings

## Timing Sensitivity

Aura is timing-sensitive.

The following are interconnected:

* Output Broadcast Rate
* UI Responsiveness
* Transition Smoothness
* Activity Logging
* PsySeg Load

Current stable setting:

outputBroadcastIntervalMs = 66

Approximate broadcast rate:

15 FPS

Do not increase without profiling.

---

# Current Known Issues

## Virtual Camera

Not implemented.

Planned:

SceneRenderer
↓
Virtual Camera Driver

---

## Installer

Developer-oriented installation only.

Packaging still required.

---

# Current Development Priorities

## Priority 1

Virtual Camera Integration

Targets:

* Teams
* Zoom
* Google Meet
* Discord
* OBS

---

## Priority 2

Executive Cleanup Pass

Goals:

* Remove orphaned code
* Remove browser-era remnants
* Remove dead routes
* Consolidate rendering paths
* Improve comments
* Executive review readiness

---

## Priority 3

Installer Packaging

Goals:

* Electron packaging
* Dependency validation
* Environment verification
* Tester distribution

---

## Priority 4

Transition Refinement

Goals:

* Slot-level transitions
* Crossfades
* Feathered blending
* Visual polish

---

# Longer-Term Roadmap

Phase 1
✓ Semantic Visual Database

Phase 2
✓ Scene Memory Engine

Phase 3
→ Virtual Camera Driver

Phase 4
→ Installer Distribution

Phase 5
→ Vector Embeddings

Phase 6
→ Semantic Scene Ranking

Phase 7
→ Multi-Agent Content Generation

---

# Development Rules

* Build incrementally
* One subsystem at a time
* Preserve modular architecture
* No full rewrites
* Keep segmentation abstracted
* Prioritize real-time performance
* Avoid hidden resource ownership
* Avoid hardcoded credentials
* Maintain reproducible installation

---

# Current Status

Aura has successfully evolved into a Semantic Visual Presentation Engine capable of maintaining and visualizing conversational context in real time.

The next milestone is Virtual Camera integration, followed by installer packaging and tester distribution.
