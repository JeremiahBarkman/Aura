# Aura Frame Transport Specification (AFTS)

**Document Version:** 0.1 Draft  
**Project:** Aura Native Runtime  
**Status:** Architecture Specification  
**Last Updated:** June 2026

---

# Purpose

The Aura Frame Transport Specification (AFTS) defines the binary protocol used to transport rendered video frames from Aura Core to native consumers.

AFTS serves as the contract between the Electron runtime and the native runtime. It intentionally abstracts away implementation details such as Media Foundation, DirectShow, Electron, or any specific operating system.

Any producer and consumer that implement AFTS can exchange Aura video frames.

---

# Design Goals

The protocol is designed to be:

- Extremely low latency
- Deterministic
- Lock-free where practical
- Versioned
- Extensible
- Cross-platform
- Independent of rendering technology
- Independent of transport implementation

The protocol must support future expansion without breaking existing implementations.

---

# Architectural Overview

```
                 Aura Core (Electron)

        SceneRenderer / PsySeg / Play Mode
                       │
                       ▼
              Frame Export Service
                       │
                 Aura Frame Transport
                 (Named Pipe / IPC)
                       │
                       ▼
                AuraFrameBridge
                       │
                Shared Memory Cache
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
 Aura Virtual     Diagnostics     Recorder
    Camera           Tool         (Future)
        │
        ▼
 Windows Camera API
        │
        ▼
 Teams • Zoom • OBS • Meet • Camera App
```

---

# Responsibilities

## Aura Core

Responsible for:

- Rendering the final composited frame
- Scene composition
- Background replacement
- Semantic decisions
- Image transitions
- Frame timing

Aura Core never communicates directly with Windows camera APIs.

---

## Frame Export Service

Responsible for:

- Packaging frame data
- Packaging frame metadata
- Sending frames through IPC

It knows nothing about:

- Media Foundation
- Shared Memory
- Virtual Cameras
- Windows APIs

---

## AuraFrameBridge

Responsible for:

- Receiving exported frames
- Frame validation
- Shared memory ownership
- Frame buffering
- Fallback frame generation
- Native synchronization

AuraFrameBridge is the boundary between Electron and native code.

---

## Consumers

Consumers include:

- Aura Virtual Camera
- Recorder
- Diagnostics
- Streaming outputs
- Future platform-specific camera implementations

Consumers never modify producer memory.

---

# Frame Lifecycle

```
Frame Rendered

        │

        ▼

Frame Exported

        │

        ▼

Frame Validated

        │

        ▼

Shared Memory Updated

        │

        ▼

Consumer Reads Frame

        │

        ▼

Frame Replaced
```

Only the latest frame is retained.

Historical frame storage is outside the scope of AFTS.

---

# Transport Layers

Current implementation:

```
Electron

↓

Named Pipe

↓

AuraFrameBridge

↓

Shared Memory

↓

Consumer
```

Future transport mechanisms may include:

- TCP
- Unix Domain Sockets
- Memory Mapped Files
- RDMA
- GPU Shared Resources

The transport mechanism is intentionally independent of the frame format.

---

# Frame Header

Current Version:

```cpp
struct AuraFrameHeader
{
    uint32_t magic;
    uint32_t version;

    uint32_t width;
    uint32_t height;

    uint32_t stride;

    uint32_t pixelFormat;

    uint64_t frameNumber;

    uint64_t timestampMs;

    uint32_t dataSize;
};
```

---

# Header Fields

| Field | Description |
|---------|-------------|
| magic | Identifies Aura frame packets |
| version | Frame protocol version |
| width | Frame width in pixels |
| height | Frame height in pixels |
| stride | Bytes per image row |
| pixelFormat | Pixel encoding |
| frameNumber | Monotonically increasing frame counter |
| timestampMs | Producer timestamp |
| dataSize | Size of pixel payload |

---

# Current Pixel Format

Version 1 supports:

```
BGRA32
```

Memory layout:

```
Byte 0   Blue

Byte 1   Green

Byte 2   Red

Byte 3   Alpha
```

32 bits per pixel.

---

# Reserved Future Formats

The protocol reserves identifiers for:

- RGBA32
- RGB24
- NV12
- P010
- YUY2
- HDR10
- 10-bit RGB
- 16-bit Floating Point

Unsupported formats must be ignored gracefully.

---

# Versioning Rules

Current protocol version:

```
Version = 1
```

Rules:

- Existing fields never change meaning.
- New fields may only be appended.
- Consumers must ignore unknown fields.
- Producers must always populate required fields.

---

# Memory Ownership

Ownership rules are strict.

Aura Core owns:

- Frame creation
- Rendering
- Scene timing

AuraFrameBridge owns:

- Transport
- Validation
- Shared memory

Consumers own:

- Frame presentation

Ownership never overlaps.

---

# Threading Model

Producer:

Single producer thread.

Consumers:

One or many independent readers.

Consumers never synchronize with one another.

Producer never waits on consumers.

Frame dropping is preferred over blocking.

---

# Synchronization Philosophy

AFTS is designed for real-time rendering.

The newest frame is always preferred.

Late frames should never block rendering.

If a consumer misses frames:

Continue with the newest available frame.

Latency is always more important than perfect frame delivery.

---

# Error Recovery

If Aura Core exits:

AuraFrameBridge continues publishing fallback frames.

If AuraFrameBridge exits:

Consumers display fallback or previous frame.

If a consumer exits:

No producer changes are required.

Subsystem failures remain isolated.

---

# Performance Targets

Target Frame Rate:

```
60 FPS
```

Preferred:

```
90 FPS
```

Maximum acceptable latency:

```
10 milliseconds
```

Preferred latency:

```
5 milliseconds
```

---

# Diagnostics

Producers should expose:

- Current frame number
- Resolution
- Pixel format
- Timestamp
- Producer version

Consumers may expose:

- Current FPS
- Dropped frames
- Average latency
- Decode time
- Shared memory status
- Pipe connection state

---

# Cross Platform Design

AFTS intentionally avoids:

- HANDLE
- HRESULT
- COM interfaces
- Windows-specific types

Only fixed-width primitive types are used.

Future Linux and macOS implementations should be able to consume identical frame packets.

---

# Security

Current implementation assumes trusted local processes.

Future versions may support:

- Producer authentication
- Signed frame headers
- Shared memory permissions
- Named pipe ACLs

Consumers must validate:

- Magic
- Version
- Frame size
- Pixel format

before reading pixel data.

---

# Future Semantic Metadata

Aura is fundamentally a semantic media platform.

Future versions of AFTS may optionally include semantic metadata alongside the rendered frame.

Example:

```cpp
struct AuraFrameMetadata
{
    uint64_t sourceItemId;

    uint64_t sceneId;

    char triggerText[128];

    float semanticScore;

    uint32_t layoutMode;

    uint32_t transitionType;

    uint64_t transitionStartTime;

    uint64_t transitionDuration;
};
```

Possible future uses:

- Diagnostics
- Scene replay
- Recording metadata
- Live streaming overlays
- Developer tools
- Analytics
- AI-assisted editing

Semantic metadata is optional and does not affect frame rendering.

---

# Native ABI

The frame header constitutes Aura's first native Application Binary Interface (ABI).

Changes to the ABI require:

- Protocol version increment
- Backward compatibility review
- Documentation update

Maintaining ABI stability allows future native components to interoperate without modification.

---

# Coding Principles

The native runtime follows these principles:

- Explicit ownership
- Single responsibility
- RAII resource management
- No hidden global state
- Immutable transport structures
- One class per file
- Minimal interdependencies
- Version-first design
- Cross-platform compatibility

---

# Future Native Components

Planned consumers of AFTS include:

- Aura Virtual Camera
- Aura Recorder
- Aura Diagnostics
- RTMP Streaming
- NDI Output
- Linux Camera Driver
- macOS Camera Driver
- GPU Frame Converter
- Hardware Encoder
- Native Performance Monitor

---

# Architectural Principle

> **Aura Core creates meaning.**

> **AFTS transports pixels and context.**

> **Native consumers present Aura to the outside world.**

Maintaining this separation of responsibilities ensures that Aura remains modular, extensible, and platform independent as the system evolves.