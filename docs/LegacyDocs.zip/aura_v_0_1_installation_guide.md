# Aura v0.1 Installation Guide

## Overview

Aura is a local-first AI semantic media system and virtual webcam platform.

Aura allows a user to:

- Record speech or text
- Generate semantic summaries and image prompts
- Build a searchable visual knowledge database
- Associate memes, slides, presentation images, and AI-generated visuals with speech
- Recall visuals dynamically in real time during live speech

Aura currently supports:

```txt
✔ Local speech ingestion
✔ Browser microphone recording
✔ Whisper transcription
✔ Ollama semantic processing
✔ ComfyUI image generation
✔ Manual image uploads
✔ Semantic trigger text generation
✔ Live Play Mode semantic matching
✔ Real-time image switching
✔ Transition effects
✔ Local SQLite database
✔ Human review / draft workflow
```

---

# System Requirements

## Recommended Hardware

### Minimum

- NVIDIA RTX GPU with 8GB VRAM
- 16GB RAM
- 50GB free SSD space
- Modern 6-core CPU

### Recommended

- RTX 4060 Ti or better
- 32GB RAM
- NVMe SSD
- CUDA-compatible NVIDIA GPU

---

# Operating System

Currently tested on:

```txt
✔ Windows 11
```

Linux support is planned.

---

# Required Software

Install the following before setting up Aura.

---

## 1. Node.js

Install latest LTS:

https://nodejs.org

Verify:

```powershell
node -v
npm -v
```

---

## 2. Python

Install:

```txt
Python 3.11+ recommended
```

Download:

https://www.python.org/downloads/

IMPORTANT:

During installation enable:

```txt
✔ Add Python to PATH
```

Verify:

```powershell
python --version
```

---

## 3. FFmpeg

Download:

https://www.gyan.dev/ffmpeg/builds/

Add FFmpeg to PATH.

Verify:

```powershell
ffmpeg -version
ffprobe -version
```

---

# Ollama Setup

Aura uses Ollama locally for semantic processing and image prompt generation.

---

## Install Ollama

Download:

https://ollama.com/download

Verify:

```powershell
ollama --version
```

---

## Pull Devstral

Example:

```powershell
ollama pull devstral
```

Verify:

```powershell
ollama list
```

---

## Test Ollama

Run:

```powershell
ollama run devstral
```

Test prompt:

```txt
Explain semantic image retrieval.
```

---

# ComfyUI Setup

Aura uses ComfyUI for local image generation.

---

## Clone ComfyUI

```powershell
mkdir C:\AI
cd C:\AI

git clone https://github.com/comfyanonymous/ComfyUI.git
```

---

## Create Python Environment

```powershell
cd C:\AI\ComfyUI

python -m venv venv
.\venv\Scripts\activate
```

---

## Install Requirements

```powershell
pip install -r requirements.txt
```

---

## IMPORTANT — CUDA PyTorch

If ComfyUI reports:

```txt
Torch not compiled with CUDA enabled
```

install CUDA-enabled PyTorch manually.

Example:

```powershell
pip uninstall torch torchvision torchaudio -y

pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
```

Verify:

```powershell
python -c "import torch; print(torch.cuda.is_available())"
```

Expected:

```txt
True
```

---

## Start ComfyUI

```powershell
cd C:\AI\ComfyUI

.\venv\Scripts\activate

python main.py --listen 127.0.0.1
```

Expected:

```txt
http://127.0.0.1:8188
```

---

# Stable Diffusion Models

Place models into:

```txt
C:\AI\ComfyUI\models\checkpoints
```

Example model used during development:

```txt
sdxl_lightning_4step.safetensors
```

---

# Aura Setup

---

## Install Aura Dependencies

From Aura root:

```powershell
cd C:\Projects\aura

npm install
```

---

## Database

Aura automatically creates:

```txt
data\aura.db
```

on first launch.

---

# Required Directory Structure

Aura currently expects:

```txt
C:\Projects\aura
C:\AI\ComfyUI
```

Important folders:

```txt
data\
data\audio\
data\images\
data\images\manual\
```

ComfyUI output directory:

```txt
C:\AI\ComfyUI\output
```

---

# Browser Requirements

Aura currently relies on browser speech recognition APIs.

Recommended browsers:

```txt
✔ Google Chrome
✔ Microsoft Edge
```

Browser microphone permissions must be enabled.

---

# Ports

Current local ports:

```txt
Aura UI      → http://localhost:5150
ComfyUI      → http://127.0.0.1:8188
Ollama API   → http://localhost:11434
```

---

# Launching Aura

---

## Option 1 — Manual Launch

### Start ComfyUI

```powershell
cd C:\AI\ComfyUI

.\venv\Scripts\activate

python main.py --listen 127.0.0.1
```

### Start Aura

```powershell
cd C:\Projects\aura

node src\web\server.js
```

Open:

```txt
http://localhost:5150
```

---

## Option 2 — Hidden Launcher

Create:

```txt
start-aura.vbs
```

Contents:

```vbscript
Set WShell = CreateObject("WScript.Shell")

WShell.CurrentDirectory = "C:\Projects\aura"

WShell.Run "cmd /c node src\web\server.js", 0, False

WScript.Sleep 3000

WShell.Run "http://localhost:5150"
```

Double-click:

```txt
start-aura.vbs
```

to launch Aura silently.

---

# First Run Validation

Verify:

```txt
✔ Aura UI loads
✔ microphone recording works
✔ Play Mode responds
✔ ComfyUI generates images
✔ records appear in DB
✔ manual uploads work
✔ live speech updates rolling transcript
✔ semantic image switching works
```

---

# Record Status Workflow

Aura uses:

```txt
draft
complete
```

states for records.

Only:

```txt
complete
```

records are eligible for Play Mode matching.

A record is considered complete when it contains:

```txt
✔ Original source text
✔ Summary text
✔ Image prompt
✔ Cleaned trigger text
✔ At least one active image
```

---

# Current Architecture Overview

Aura currently operates as:

```txt
speech/text
→ semantic processing
→ trigger generation
→ image generation/upload
→ local semantic database
→ live semantic matching
→ dynamic image recall
```

---

# Current Major Features

## Record Mode

```txt
✔ Text ingestion
✔ Audio recording
✔ Whisper transcription
✔ Ollama semantic processing
✔ ComfyUI image generation
✔ Manual image upload
✔ Record editing
✔ Multi-image support
✔ Record completion workflow
```

---

## Play Mode

```txt
✔ Browser speech recognition
✔ Rolling transcript memory
✔ Semantic keyword overlap matching
✔ Real-time image switching
✔ Transition settings
✔ Active visual display
✔ Match scoring
✔ Draft filtering
```

---

# Known Current Limitations

```txt
✖ PsySeg segmentation not integrated yet
✖ Virtual webcam output not implemented yet
✖ No vector embedding search yet
✖ Browser speech recognition currently required
✖ Windows-first development
```

---

# Troubleshooting

## ComfyUI Starts Then Exits

Ensure:

```txt
CUDA-enabled PyTorch installed
```

Verify:

```powershell
python -c "import torch; print(torch.cuda.is_available())"
```

---

## Browser Speech Recognition Fails

Use:

```txt
Chrome or Edge
```

Ensure microphone permissions are enabled.

---

## Images Not Appearing

Verify:

```txt
C:\AI\ComfyUI\output
```

contains generated images.

---

## Play Mode Not Matching

Verify records are marked:

```txt
complete
```

and contain active images.

---

# Aura Philosophy

Aura is designed as:

```txt
a semantic visual memory system
```

The user speaks naturally, and Aura recalls contextual visuals, slides, memes, images, and presentation media dynamically in real time.

