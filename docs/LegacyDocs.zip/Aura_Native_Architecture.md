# Aura Native Architecture
Version: 0.1
Status: Draft

---

# Purpose

The Aura Native subsystem provides Windows-native functionality that cannot be implemented efficiently or reliably inside Electron.

The native subsystem is responsible for:

- Virtual camera
- Frame bridge
- Native Windows APIs
- Shared memory
- IPC
- Future GPU acceleration
- Native installer support

The native subsystem is NOT responsible for:

- User interface
- Semantic processing
- Database
- Speech recognition
- Image generation
- Play Mode logic
- Scene composition

Those responsibilities remain inside Aura Core.

---

# Design Philosophy

Aura follows a layered architecture.

Every layer has a single responsibility.

Dependencies always flow downward.

No subsystem may depend on UI code.

No subsystem may depend on implementation details of another subsystem.

---

# High-Level Architecture

                    Electron UI
                         │
                         ▼
                    Aura Core
                         │
             (Frame Export Service)
                         │
                Named Pipe / IPC
                         │
                         ▼
               AuraFrameBridge
                         │
                  Shared Memory
                         │
                         ▼
             AuraVirtualCamera
                         │
                  Media Foundation
                         │
                         ▼
                Windows Camera API
                         │
                         ▼
        Zoom / Teams / OBS / Camera App

---

# Native Projects

AuraNative.slnx

    AuraFrameBridge

    AuraVirtualCamera

    AuraDiagnostics

    AuraInstaller

---

# AuraFrameBridge

Purpose

Receive completed Aura frames and expose them to native consumers.

Responsibilities

- Shared memory
- IPC
- Frame validation
- Frame buffering
- Fallback frame generation
- Synchronization

Never responsible for

- Media Foundation
- COM
- Camera registration
- Electron UI
- PsySeg
- Database

---

# AuraVirtualCamera

Purpose

Expose Aura as a Windows camera device.

Responsibilities

- Register camera
- Media Foundation source
- Frame conversion
- Camera lifecycle
- Device registration

Never responsible for

- Shared memory ownership
- Named pipes
- UI
- Electron

---

# AuraDiagnostics

Purpose

Developer debugging tools.

Displays

- Current FPS
- Latest frame
- Shared memory status
- Pipe status
- Camera status
- Dropped frames

Never modifies production behavior.

---

# AuraInstaller

Purpose

Install and maintain Windows-native components.

Responsibilities

- Register virtual camera
- Install native binaries
- Verify runtime requirements
- Clean uninstall

---

# Data Ownership

Aura Core owns all rendered frames.

AuraFrameBridge owns transport.

AuraVirtualCamera owns presentation to Windows.

Ownership never overlaps.

---

# Threading Rules

Each subsystem owns its own threads.

No thread may directly manipulate another subsystem's state.

Communication occurs only through:

- Named Pipes
- Shared Memory
- Immutable frame structures

---

# Frame Lifetime

Frame created

↓

Validated

↓

Written to shared memory

↓

Consumed by camera

↓

Overwritten by newer frame

No historical frame storage exists in native memory.

---

# Error Handling

Subsystems fail independently.

If AuraFrameBridge stops:

Virtual camera displays fallback.

If Virtual Camera stops:

Aura continues rendering.

If Electron stops:

Bridge displays fallback frames.

No subsystem crash may terminate another subsystem.

---

# Logging

Every native subsystem has independent logging.

Logs never depend on Electron.

Future location:

native/logs/

---

# Coding Standards

One class per file.

One responsibility per class.

Header contains interface.

CPP contains implementation.

No global mutable state.

RAII preferred.

No hidden ownership.

Explicit lifetime management.

No circular dependencies.

---

# Future Native Projects

GPU frame conversion

Linux camera implementation

macOS camera implementation

Native audio bridge

Hardware acceleration

Performance diagnostics

---

# Architectural Principle

Aura Core creates meaning.

Native code delivers pixels.

Those responsibilities remain permanently separated.